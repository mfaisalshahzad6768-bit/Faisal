"""Local checks for Python source files."""

from __future__ import annotations

import ast
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


@dataclass(frozen=True)
class Issue:
    path: str
    line: int
    code: str
    message: str

    def __str__(self) -> str:
        return f"{self.path}:{self.line}: {self.code}: {self.message}"


def python_files(target: Path) -> Iterable[Path]:
    """Yield Python files beneath a file or directory target."""
    if target.is_file():
        if target.suffix == ".py":
            yield target
        return

    if target.is_dir():
        for path in sorted(target.rglob("*.py")):
            # Ignore common generated/vendor directories.
            if any(part in {".git", ".venv", "venv", "__pycache__"} for part in path.parts):
                continue
            yield path


def scan_file(path: Path, max_line_length: int = 88) -> list[Issue]:
    """Inspect one Python file and return all detected issues."""
    issues: list[Issue] = []
    try:
        source = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return [Issue(str(path), 1, "encoding", "File is not valid UTF-8.")]
    except OSError as exc:
        return [Issue(str(path), 1, "read-error", str(exc))]

    lines = source.splitlines()
    for number, line in enumerate(lines, start=1):
        if line.rstrip(" \t") != line:
            issues.append(Issue(str(path), number, "trailing-whitespace",
                                "Remove whitespace at the end of this line."))
        if "\t" in line:
            issues.append(Issue(str(path), number, "tab-character",
                                "Use spaces instead of tab characters."))
        if len(line) > max_line_length:
            issues.append(Issue(str(path), number, "long-line",
                                f"Line is {len(line)} characters (limit: {max_line_length})."))
        stripped = line.strip()
        if "TODO" in stripped:
            issues.append(Issue(str(path), number, "todo", "TODO note found."))
        if "FIXME" in stripped:
            issues.append(Issue(str(path), number, "fixme", "FIXME note found."))

    try:
        ast.parse(source, filename=str(path))
    except SyntaxError as exc:
        issues.append(Issue(str(path), exc.lineno or 1, "syntax-error",
                            exc.msg or "Invalid Python syntax."))

    return issues


def scan_target(target: Path, max_line_length: int = 88) -> tuple[int, list[Issue]]:
    """Scan a path and return (number_of_files_scanned, issues)."""
    if not target.exists():
        raise FileNotFoundError(f"Path does not exist: {target}")
    files = list(python_files(target))
    issues: list[Issue] = []
    for path in files:
        issues.extend(scan_file(path, max_line_length=max_line_length))
    return len(files), issues
