"""Command-line interface for CodeSaathi."""

import argparse
from pathlib import Path

from .scanner import scan_target


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="codesaathi",
        description="Scan Python files for common issues locally.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)
    scan = subparsers.add_parser("scan", help="Scan a Python file or directory.")
    scan.add_argument("path", type=Path, help="File or directory to scan.")
    scan.add_argument(
        "--max-line-length", type=int, default=88,
        help="Maximum permitted line length (default: 88).",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.max_line_length < 1:
        print("Error: --max-line-length must be greater than zero.")
        return 2

    try:
        count, issues = scan_target(args.path, args.max_line_length)
    except (FileNotFoundError, NotADirectoryError) as exc:
        print(f"Error: {exc}")
        return 2

    print("CodeSaathi report")
    print(f"Files scanned: {count}")
    print(f"Issues found: {len(issues)}")
    for issue in issues:
        print(issue)

    return 1 if issues else 0
