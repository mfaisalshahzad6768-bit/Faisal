# CodeSaathi

**A small, privacy-friendly Python project checker for beginner developers.**

CodeSaathi scans Python files and reports common issues without uploading source code anywhere. It is designed for students, solo developers, and open-source contributors who want a quick local review before committing code.

## Features

- Checks Python syntax errors.
- Finds trailing whitespace and tab indentation.
- Flags lines longer than a configurable limit.
- Finds `TODO` and `FIXME` notes.
- Supports scanning a single file or a directory.
- Returns a non-zero exit code when issues are found, so it can be used in scripts and CI.
- Runs locally; it does not send code to an external service.

## Requirements

- Python 3.9 or newer
- No third-party dependencies

## Quick start

```bash
python -m codesaathi scan .
```

If you have installed the package:

```bash
codesaathi scan . --max-line-length 100
```

## Example output

```text
CodeSaathi report
Files scanned: 3
Issues found: 2

src/example.py:12: trailing-whitespace: Remove whitespace at the end of this line.
src/example.py:18: long-line: Line is 112 characters (limit: 100).
```

## Development

Run tests with:

```bash
python -m unittest discover -s tests -v
```

Run the CLI from the repository root:

```bash
PYTHONPATH=src python -m codesaathi scan .
```

## Roadmap

- Add configurable ignore patterns.
- Add JSON output for CI integrations.
- Add support for additional languages.
- Add GitHub Actions workflow.

## Contributing

Contributions are welcome. Please open an issue to discuss larger changes, include tests for bug fixes, and keep the tool dependency-free where practical.

## License

MIT. See [LICENSE](LICENSE).
