import tempfile
import unittest
from pathlib import Path

from codesaathi.scanner import scan_file, scan_target


class ScannerTests(unittest.TestCase):
    def test_detects_trailing_whitespace_and_long_line(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "sample.py"
            path.write_text("name = 'Sam'  \n" + "x = '" + ("a" * 90) + "'\n",
                            encoding="utf-8")
            issues = scan_file(path, max_line_length=88)
            codes = {issue.code for issue in issues}
            self.assertIn("trailing-whitespace", codes)
            self.assertIn("long-line", codes)

    def test_detects_syntax_error(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "broken.py"
            path.write_text("def broken(:\n", encoding="utf-8")
            issues = scan_file(path)
            self.assertIn("syntax-error", {issue.code for issue in issues})

    def test_scan_target_counts_files(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "ok.py"
            path.write_text("print('hello')\n", encoding="utf-8")
            count, issues = scan_target(Path(directory))
            self.assertEqual(count, 1)
            self.assertEqual(issues, [])


if __name__ == "__main__":
    unittest.main()
